import { AnchorDirective } from './anchor.directive';

describe('NodeDirective', () => {
  it('should create an instance', () => {
    const directive = new AnchorDirective();
    expect(directive).toBeTruthy();
  });
});
