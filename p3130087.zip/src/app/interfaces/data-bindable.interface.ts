/**
 * An interface to be extended by specific components
 */
export interface DataBindable {
    data: any;
}
