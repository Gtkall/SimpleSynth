import { VCFNode } from './vcf-node';

describe('VCFNode', () => {
  it('should create an instance', () => {
    expect(new VCFNode()).toBeTruthy();
  });
});
