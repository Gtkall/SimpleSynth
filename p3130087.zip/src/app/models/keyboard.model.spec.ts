import { Keyboard } from './keyboard.model';

describe('Keyboard.Model', () => {
  it('should create an instance', () => {
    expect(new Keyboard()).toBeTruthy();
  });
});
