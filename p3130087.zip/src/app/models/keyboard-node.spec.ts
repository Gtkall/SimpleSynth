import { CustomKeyboardNode } from './keyboard-node';

describe('KeyboardNode', () => {
  it('should create an instance', () => {
    expect(new CustomKeyboardNode()).toBeTruthy();
  });
});
