import { CustomOscillatorNode } from './oscillator-node';

describe('OscillatorNode', () => {
  it('should create an instance', () => {
    expect(new CustomOscillatorNode()).toBeTruthy();
  });
});
