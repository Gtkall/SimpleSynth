import { LFONode } from './lfo-node';

describe('LFONode', () => {
  it('should create an instance', () => {
    expect(new LFONode()).toBeTruthy();
  });
});
