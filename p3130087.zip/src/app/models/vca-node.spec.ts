import { VCANode } from './vca-node';

describe('VCANode', () => {
  it('should create an instance', () => {
    expect(new VCANode()).toBeTruthy();
  });
});
